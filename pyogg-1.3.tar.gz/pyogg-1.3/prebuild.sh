#!/bin/sh

# This is just a simple script to be run before any automatic
# binary distribution building (like bdist or bdist_rpm). You
# probably don't have to worry about it.

python config_unix.py
