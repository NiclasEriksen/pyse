#include "general.h"
#include <pyogg/pyogg.h>

/* for now, just take arg_to_int64 from pyogg */
